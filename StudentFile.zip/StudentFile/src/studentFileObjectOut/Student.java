/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentFileObjectOut;

import java.io.Serializable;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author nur13
 */
public class Student  implements Serializable {

    @Override
    public String toString() {
        return "Student{" + "id=" + id + ", age=" + age + ", name=" + name + ", surname=" + surname + '}';
    } 

    public static Student[] studentArr = null;
    public String id;
    public int age;
    public String name;
    public String surname;

    public Student(String name, String surname, int age, String id) {
        this.id = id;
        this.age = age;
        this.name = name;
        this.surname = surname;
    }

    public Student() {

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

   

   

   
}
