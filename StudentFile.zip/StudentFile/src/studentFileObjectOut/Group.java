/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentFileObjectOut;

import java.util.Scanner;

/**
 *
 * @author nur13
 */
public class Group extends Super {
    Scanner s=new Scanner(System.in);
    
    public static Group groupArr[]=null;
    public String groupName;
    public String countStudent;
    public String speciality;

    
    public Group(){
        
    }

    public Group(String groupName, String speciality, String countStudent) {
        this.groupName = groupName;
        this.countStudent = countStudent;
        this.speciality = speciality;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getCountStudent() {
        return countStudent;
    }

    public void setCountStudent(String countStudent) {
        this.countStudent = countStudent;
    }

    public String getSpeciality() {
        return speciality;
    }

    public void setSpeciality(String speciality) {
        this.speciality = speciality;
    }

    @Override
    public void add() {
        Scanner s = new Scanner(System.in);
        System.out.println("Nece qrup qeydıyyatdan kecirilecek?");
        int count = s.nextInt();
        groupArr = new Group[count];

        for (int i = 0; i < count; i++) {

            System.out.println((i + 1) + "-ci Qrup:");

            s = new Scanner(System.in);
            System.out.println("Qrup adini daxil edin:");
            String groupName = s.nextLine();

            s = new Scanner(System.in);
            System.out.println("Qrup ixtisasi daxil edin:");
            String speciality = s.nextLine();

            s = new Scanner(System.in);
            System.out.println("Qrupdaki telebe sayini daxil edin:");
            String countStudent = s.nextLine();

            Group gp = new Group(groupName,speciality,countStudent);
            groupArr[i] = gp;

        }
        System.out.println("Qeydiyyat ughurla tamamlandi");
        Group.chap();
    }
    public static void chap() {
        for (int i = 0; i < groupArr.length; i++) {
            Group gp = groupArr[i];
            System.out.println((i+1)+ ".Qrup adi: " + gp.getGroupName() + " Ixtisas: "
                    + gp.getSpeciality() + " Telebe sayi: " + gp.getCountStudent());
        }
    }

    @Override
    public void update() {
        Group.chap();
        System.out.println("Deyishiklik etmek istediyiniz qrupun indeksini sechin:");
        int index=s.nextInt();
        System.out.println("Yeni melumatlari elave edin:");
        
        s = new Scanner(System.in);
        System.out.println("Qrup adini daxil edin:");
        String groupName = s.nextLine();

        s = new Scanner(System.in);
        System.out.println("Qrup ixtisasi daxil edin:");
        String speciality = s.nextLine();

        s = new Scanner(System.in);
        System.out.println("Qrupdaki telebe sayini daxil edin:");
        String countStudent = s.nextLine();
        
        Group gp1=new Group(groupName,speciality,countStudent);
        groupArr[index-1]=gp1;
        System.out.println("Deyishdirildi.");
        Group.chap();
    }

    @Override
    public void delete() {
        Group.chap();
        System.out.println("Melumatlarini silmek istediyiniz muellimin indeksini sechin:");
        int index = s.nextInt();
        Group gp2 = new Group();
        groupArr[index - 1] = gp2;
        Group.chap();
    }

    @Override
    public void search() {
        Scanner s = new Scanner(System.in);
        System.out.println("Axtarmaq istediyiniz qrupun adini ve ya ixtisasini daxil edin:");
        String search = s.nextLine();

        for (int i = 0; i < groupArr.length; i++) {
            Group gp = groupArr[i];
            if (gp.getGroupName().equals(search) || gp.getSpeciality().equals(search));
            {
                System.out.println("Qrup adi: "+gp.getGroupName() + " Ixtisas: "
                        + gp.getSpeciality() + " Telebe sayi: " + gp.getCountStudent());
            }
        }
    }
    
    
    
    
}
