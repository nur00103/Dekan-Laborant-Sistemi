/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentFileObjectOut;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/**
 *
 * @author nur13
 */
public class FileWriteRead {

    /**
     *
     * @param obj
     * @param fileName
     * @throws Exception
     */
    public static void writeStudent(Student obj, String fileName) throws Exception {
         try (FileOutputStream fos = new FileOutputStream(fileName,true);
                ObjectOutputStream oos = new ObjectOutputStream(fos);) {
            oos.writeObject(obj);
            oos.flush();
        }
    }

    public static Student readStudent(String fileName) throws Exception {
        Student result = null;
        try (FileInputStream fis = new FileInputStream(fileName);
                ObjectInputStream ois = new ObjectInputStream(fis);) {
                result=(Student)ois.readObject();
        }return result;
       
    }
    
}
   
