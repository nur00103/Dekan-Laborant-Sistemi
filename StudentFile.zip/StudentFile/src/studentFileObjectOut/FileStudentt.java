/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentFileObjectOut;

import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import static studentFileObjectOut.Student.studentArr;

/**
 *
 * @author nur13
 */
public class FileStudentt extends Super {

    Scanner s = new Scanner(System.in);

    public static void print() {
        for (int i = 0; i < studentArr.length; i++) {
            Student student = studentArr[i];
            System.out.println(
                    (i + 1) + "."
                    + student.getName() + " "
                    + student.getSurname() + " " + student.getAge()
                    + " " + student.getId());
        }
    }

    @Override
    public void add() throws Exception {

        s = new Scanner(System.in);
        System.out.println("Nece telebe qeydıyyatdan kecirilecek?");
        int count = s.nextInt();
        studentArr = new Student[count];

        for (int i = 0; i < count; i++) {

            System.out.println((i + 1) + "-ci telebe:");

            s = new Scanner(System.in);
            System.out.println("Adi daxil edin:");
            String name = s.nextLine();

            s = new Scanner(System.in);
            System.out.println("Soyadi daxil edin:");
            String surname = s.nextLine();

            s = new Scanner(System.in);
            System.out.println("Yashi daxil edin:");
            int age = s.nextInt();

            s = new Scanner(System.in);
            System.out.println("ID daxil edin:");
            String id = s.nextLine();

            Student student = new Student(name, surname, age, id);
            studentArr[i] = student;
            //FileWriteRead.writeStudent(student, "StudentTest3.txt");
            
        }
        System.out.println("Qeydiyyat ughurla tamamlandi");
        print();

    }

    @Override
    public void search() {
        Scanner s = new Scanner(System.in);
        System.out.println("Ad,Soyad ve ya ID daxil edin:");
        String search = s.nextLine();

        for (int i = 0; i < studentArr.length; i++) {
            Student student = studentArr[i];
            if (student.getId().equals(search) || student.getName().equals(search) || student.getSurname().equals(search)) {
                System.out.println(student.getName() + " "
                        + student.getSurname() + " " + student.getAge()
                        + " " + student.getId());
                break;
            } else {
                System.out.println("Melumat sistemde tapilmadi");
            }
        }
    }

    @Override
    public void update() {

        System.out.println("Deyishiklik etmek istediyiniz telebenin indeksini sechin:");
        int indeks = s.nextInt();
        System.out.println("Deyishdirilmish melumatlari daxil edin:");

        s = new Scanner(System.in);
        System.out.println("Adi daxil edin:");
        String name = s.nextLine();

        s = new Scanner(System.in);
        System.out.println("Soyadi daxil edin:");
        String surname = s.nextLine();

        s = new Scanner(System.in);
        System.out.println("Yashi daxil edin:");
        int age = s.nextInt();

        s = new Scanner(System.in);
        System.out.println("ID daxil edin:");
        String id = s.nextLine();

        Student student1 = new Student(name, surname, age, id);
        Student.studentArr[indeks - 1] = student1;

    }

    @Override
    public void delete() {

        System.out.println("Melumatlarini silmek istediyiniz telebenin indeksini sechin:");
        int index = s.nextInt();
        Student st = new Student();
        studentArr[index - 1] = st;

    }
}
