/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package StudentFileBuffer;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/**
 *
 * @author nur13
 */
public class FileStudent {

    public static void writeWithBuffer(Student[] studentArr) throws Exception {
        try (FileWriter f = new FileWriter("StudentBuf.txt");
                BufferedWriter b = new BufferedWriter(f);) {
            for (int i = 0; i < studentArr.length; i++) {
                b.write("1-ci telebe:" + studentArr[i].getName() + " " + studentArr[i].getSurname() + " " + studentArr[i].getAge() + " " + studentArr[i].getId());
                b.newLine();
            }
        }
    }

    public static void readWithBuffer() throws Exception {
        try (FileReader f = new FileReader("StudentBuf.txt");
                BufferedReader b = new BufferedReader(f);) {
            String result;
            while((result=b.readLine())!=null)

                System.out.println(result);
        }
    
}
}