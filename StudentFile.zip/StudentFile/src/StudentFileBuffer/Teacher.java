/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package StudentFileBuffer;

import java.util.Scanner;

/**
 *
 * @author nur13
 */
public class Teacher extends Super {

    Scanner s = new Scanner(System.in);

    public String id;
    public String name;
    public String surname;

    public static Teacher teacherArr[] = null;

    public Teacher() {

    }

    public Teacher(String id, String name, String surname) {
        this.id = id;
        this.name = name;
        this.surname = surname;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    @Override
    public void add() {
        Scanner s = new Scanner(System.in);
        System.out.println("Nece muellim qeydıyyatdan kecirilecek?");
        int count = s.nextInt();
        teacherArr = new Teacher[count];

        for (int i = 0; i < count; i++) {

            System.out.println((i + 1) + "-ci Muellim:");

            s = new Scanner(System.in);
            System.out.println("Adi daxil edin:");
            String name = s.nextLine();

            s = new Scanner(System.in);
            System.out.println("Soyadi daxil edin:");
            String surname = s.nextLine();

            s = new Scanner(System.in);
            System.out.println("ID daxil edin:");
            String id = s.nextLine();

            Teacher tc = new Teacher(id, name, surname);
            teacherArr[i] = tc;

        }
        System.out.println("Qeydiyyat ughurla tamamlandi");
        Teacher.chap();
    }

    public static void chap() {
        for (int i = 0; i < teacherArr.length; i++) {
            Teacher tc = teacherArr[i];
            System.out.println((i + 1) + "." + tc.getName() + " "
                    + tc.getSurname() + " " + tc.getId());
        }
    }

    @Override
    public void search() {
        Scanner s = new Scanner(System.in);
        System.out.println("Axtarmaq istediyiniz muellimin adini,soyadini ve ya ID-sini daxil edin:");
        String search = s.nextLine();

        for (int i = 0; i < teacherArr.length; i++) {
            Teacher tc = teacherArr[i];
            if (tc.getName().equals(search) || tc.getName().equals(search) || tc.getSurname().equals(search));
            {
                System.out.println(tc.getName() + " "
                        + tc.getSurname() + " " + tc.getId());
            }
        }
    }

    @Override
    public void update() {
        Teacher.chap();
        System.out.println("Deyishiklik etmek istediyiniz muellimin indeksini sechin:");
        int index = s.nextInt();
        System.out.println("Yeni melumatlari elave edin:");

        s = new Scanner(System.in);
        System.out.println("Adi daxil edin:");
        String name = s.nextLine();

        s = new Scanner(System.in);
        System.out.println("Soyadi daxil edin:");
        String surname = s.nextLine();

        s = new Scanner(System.in);
        System.out.println("ID daxil edin:");
        String id = s.nextLine();

        Teacher tc1 = new Teacher(id, name, surname);
        teacherArr[index - 1] = tc1;
        System.out.println("Deyishdirildi.");
        Teacher.chap();

    }

    @Override
    public void delete() {
        Teacher.chap();
        System.out.println("Melumatlarini silmek istediyiniz muellimin indeksini sechin:");
        int index = s.nextInt();
        Teacher tc1 = new Teacher();
        teacherArr[index - 1] = tc1;
        Teacher.chap();
    }

}
