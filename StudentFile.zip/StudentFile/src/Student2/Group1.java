/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Student2;

import StudentFileBuffer.Super;
import java.util.Scanner;

/**
 *
 * @author nur13
 */
public class Group1 extends Super {
    Scanner s=new Scanner(System.in);
    
    public static Group1 groupArr[]=null;
    public String groupName;
    public String countStudent;
    public String speciality;

    
    public Group1(){
        
    }

    public Group1(String groupName, String speciality, String countStudent) {
        this.groupName = groupName;
        this.countStudent = countStudent;
        this.speciality = speciality;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getCountStudent() {
        return countStudent;
    }

    public void setCountStudent(String countStudent) {
        this.countStudent = countStudent;
    }

    public String getSpeciality() {
        return speciality;
    }

    public void setSpeciality(String speciality) {
        this.speciality = speciality;
    }

    @Override
    public void add() {
        Scanner s = new Scanner(System.in);
        System.out.println("Nece qrup qeydıyyatdan kecirilecek?");
        int count = s.nextInt();
        groupArr = new Group1[count];

        for (int i = 0; i < count; i++) {

            System.out.println((i + 1) + "-ci Qrup:");

            s = new Scanner(System.in);
            System.out.println("Qrup adini daxil edin:");
            String groupName = s.nextLine();

            s = new Scanner(System.in);
            System.out.println("Qrup ixtisasi daxil edin:");
            String speciality = s.nextLine();

            s = new Scanner(System.in);
            System.out.println("Qrupdaki telebe sayini daxil edin:");
            String countStudent = s.nextLine();

            Group1 gp = new Group1(groupName,speciality,countStudent);
            groupArr[i] = gp;

        }
        System.out.println("Qeydiyyat ughurla tamamlandi");
        Group1.chap();
    }
    public static void chap() {
        for (int i = 0; i < groupArr.length; i++) {
            Group1 gp = groupArr[i];
            System.out.println((i+1)+ ".Qrup adi: " + gp.getGroupName() + " Ixtisas: "
                    + gp.getSpeciality() + " Telebe sayi: " + gp.getCountStudent());
        }
    }

    @Override
    public void update() {
        Group1.chap();
        System.out.println("Deyishiklik etmek istediyiniz qrupun indeksini sechin:");
        int index=s.nextInt();
        System.out.println("Yeni melumatlari elave edin:");
        
        s = new Scanner(System.in);
        System.out.println("Qrup adini daxil edin:");
        String groupName = s.nextLine();

        s = new Scanner(System.in);
        System.out.println("Qrup ixtisasi daxil edin:");
        String speciality = s.nextLine();

        s = new Scanner(System.in);
        System.out.println("Qrupdaki telebe sayini daxil edin:");
        String countStudent = s.nextLine();
        
        Group1 gp1=new Group1(groupName,speciality,countStudent);
        groupArr[index-1]=gp1;
        System.out.println("Deyishdirildi.");
        Group1.chap();
    }

    @Override
    public void delete() {
        Group1.chap();
        System.out.println("Melumatlarini silmek istediyiniz muellimin indeksini sechin:");
        int index = s.nextInt();
        Group1 gp2 = new Group1();
        groupArr[index - 1] = gp2;
        Group1.chap();
    }

    @Override
    public void search() {
        Scanner s = new Scanner(System.in);
        System.out.println("Axtarmaq istediyiniz qrupun adini ve ya ixtisasini daxil edin:");
        String search = s.nextLine();

        for (int i = 0; i < groupArr.length; i++) {
            Group1 gp = groupArr[i];
            if (gp.getGroupName().equals(search) || gp.getSpeciality().equals(search));
            {
                System.out.println("Qrup adi: "+gp.getGroupName() + " Ixtisas: "
                        + gp.getSpeciality() + " Telebe sayi: " + gp.getCountStudent());
            }
        }
    }
    
    
    
    
}
