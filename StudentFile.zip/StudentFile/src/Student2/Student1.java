/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Student2;

import java.io.Serializable;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author nur13
 */
public class Student1 extends Super1  {



    Scanner s = new Scanner(System.in);

    public static Student1[] studentArr = null;
    public String id;
    public int age;
    public String name;
    public String surname;

    public Student1(String name, String surname, int age, String id) {
        this.id = id;
        this.age = age;
        this.name = name;
        this.surname = surname;
    }

    public Student1() {

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    

    public static void print()  {
       for (int i = 0; i < studentArr.length; i++) {
          Student1 student1 = studentArr[i];
            System.out.println(
                    (i + 1) + "." +
                            student1.getName() + " "
                    + student1.getSurname() + " " + student1.getAge()
                    + " " + student1.getId());        }
    }

    @Override
    public void search() {
        Scanner s = new Scanner(System.in);
        System.out.println("Ad,Soyad ve ya ID daxil edin:");
        String search = s.nextLine();

        for (int i = 0; i < studentArr.length; i++) {
            Student1 student = studentArr[i];
            if (student.getId().equals(search) || student.getName().equals(search) || student.getSurname().equals(search)) {
                System.out.println(student.getName() + " "
                        + student.getSurname() + " " + student.getAge()
                        + " " + student.getId());
                break;
            }
            else {
                System.out.println("Melumat sistemde tapilmadi");
            }
        }
    }

    @Override
    public void update() {
        
        System.out.println("Deyishiklik etmek istediyiniz telebenin indeksini sechin:");
        int indeks = s.nextInt();
        System.out.println("Deyishdirilmish melumatlari daxil edin:");

        s = new Scanner(System.in);
        System.out.println("Adi daxil edin:");
        String name = s.nextLine();

        s = new Scanner(System.in);
        System.out.println("Soyadi daxil edin:");
        String surname = s.nextLine();

        s = new Scanner(System.in);
        System.out.println("Yashi daxil edin:");
        int age = s.nextInt();

        s = new Scanner(System.in);
        System.out.println("ID daxil edin:");
        String id = s.nextLine();

        Student1 student1 = new Student1(name, surname, age, id);
        Student1.studentArr[indeks - 1] = student1;
        

    }

    @Override
    public void delete() {
        
        System.out.println("Melumatlarini silmek istediyiniz telebenin indeksini sechin:");
        int index = s.nextInt();
        Student1 st=new Student1();
        studentArr[index-1]=st;
        
    }

    @Override
    public Student1 add(String nameSt, String surnameSt, int ageSt, String idSt) {
        
            Student1 student1 = new Student1(nameSt, surnameSt, ageSt, idSt);
            return student1;
        }        
}
        
   

