package Student2;

import StudentFileBuffer.Group;
import StudentFileBuffer.Teacher;
import java.util.Scanner;

public class Main1 {

    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);
        Student1 student1 = new Student1();
        Teacher tc = new Teacher();
        Group gp = new Group();
        try {
            while (true) {

                System.out.println("Hansi sisteme kechid etmek isteyirsiniz?"
                        + "\n1.Telebe"
                        + "\n2.Muellim"
                        + "\n3.Qrup"
                        + "\n4.Ders");
                int operation = s.nextInt();
                if (operation == 1) {
                    while (true) {
                        System.out.println("Telebe sistemi.Hansi emeliyyati icra etmek isteyirsiniz?"
                                + "\n1.Telebe qeydiyyat"
                                + "\n2.Telebe axtarishi"
                                + "\n3.Telebe melumatlarini yenilemek"
                                + "\n4.Telebe melumatlarini silmek"
                                + "\n0.Sistemi deyishmek ");
                        int emeliyyat = s.nextInt();
                        if (emeliyyat == 1) {
                            s = new Scanner(System.in);
                            System.out.println("Nece telebe qeydıyyatdan kecirilecek?");
                            int count = s.nextInt();
                            student1.studentArr=new Student1[count];

                            for (int i = 0; i < count; i++) {

                                System.out.println((i + 1) + "-ci telebe:");

                                s = new Scanner(System.in);
                                System.out.println("Adi daxil edin:");
                                String name = s.nextLine();

                                s = new Scanner(System.in);
                                System.out.println("Soyadi daxil edin:");
                                String surname = s.nextLine();

                                s = new Scanner(System.in);
                                System.out.println("Yashi daxil edin:");
                                int age = s.nextInt();

                                s = new Scanner(System.in);
                                System.out.println("ID daxil edin:");
                                String id = s.nextLine();  
                                
                                student1.studentArr[i]=student1.add(name,surname,age,id);
                                
                            }System.out.println("Qeydiyyat ughurla tamamlandi");
                            Student1.print();
                        }else if (emeliyyat == 2) {
                            student1.search();
                        } else if (emeliyyat == 3) {
                            student1.update();
                        } else if (emeliyyat == 4) {
                            student1.delete();
                        } else if (emeliyyat == 0) {
                            break;
                        } else {
                            System.out.println("Emeliyyat indeksini siyahidan secdiyinize emin olun!");
                        }
                        }
                    }else if (operation == 2) {
                    while (true) {
                        System.out.println("Muellim sistemi\nHansi emeliyyati icra etmek isteyirsiniz?"
                                + "\n1.Muellim qeydiyyat"
                                + "\n2.Muellim axtarishi"
                                + "\n3.Muellim melumatlarini yenilemek"
                                + "\n4.Muellim melumatlarini silmek"
                                + "\n0.Sistemi deyishmek ");
                        int emeliyyat = s.nextInt();
                        if (emeliyyat == 1) {
                            tc.add();
                        } else if (emeliyyat == 2) {
                            tc.search();
                        } else if (emeliyyat == 3) {
                            tc.update();
                        } else if (emeliyyat == 4) {
                            tc.delete();
                        } else if (emeliyyat == 0) {
                            break;
                        } else {
                            System.out.println("Emeliyyat indeksini siyahidan secdiyinize emin olun!");
                        }
                    }
                }else if (operation==3) {
                    while (true) {
                        System.out.println("Qrup sistemi\nHansi emeliyyati icra etmek isteyirsiniz?"
                                + "\n1.Qrup elave etmek"
                                + "\n2.Qrup axtarishi"
                                + "\n3.Qrup melumatlarini yenilemek"
                                + "\n4.Qrup melumatlarini silmek"
                                + "\n0.Sistemi deyishmek ");
                        int emeliyyat = s.nextInt();
                        if (emeliyyat == 1) {
                            gp.add();
                        } else if (emeliyyat == 2) {
                            gp.search();
                        } else if (emeliyyat == 3) {
                            gp.update();
                        } else if (emeliyyat == 4) {
                            gp.delete();
                        } else if (emeliyyat == 0) {
                            break;
                        } else {
                            System.out.println("Emeliyyat indeksini siyahidan secdiyinize emin olun!");
                        }
                    }
                }
                }
            }catch (Exception e) {
            System.out.println("Melumatlari duzgun daxil edin.");

        }
        }
    }
