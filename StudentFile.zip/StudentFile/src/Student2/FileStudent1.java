/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Student2;

import StudentFileBuffer.Student;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/**
 *
 * @author nur13
 */
public class FileStudent1 {

    public static void writeStudent(Student obj, String fileName) throws Exception {
        try (
                FileOutputStream fos = new FileOutputStream(fileName);
                ObjectOutputStream oos = new ObjectOutputStream(fos);)
        {
            oos.writeObject(obj);
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }

    public static Object readStudent(String fileName) throws Exception {
        Object obj = null;
        try (FileInputStream fis = new FileInputStream(fileName);
                ObjectInputStream ois = new ObjectInputStream(fis);) {
                obj=ois.readObject();
        }finally {
            return obj;
        }
    }
}
