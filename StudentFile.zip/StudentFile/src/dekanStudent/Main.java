package dekanStudent;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    List<User> users = new ArrayList<>();

    public static void main(String[] args) throws Exception {
        List<User> users = WriteFile.readLogin();
        List<Telebe> students = WriteFile.readStudents2();
        Scanner s = new Scanner(System.in);
        boolean b = false;
        while (true) {
            System.out.println("Istifadechi adini daxil edin:");
            String username = s.nextLine();
            System.out.println("Shifreni daxil edin:");
            String password = s.nextLine();
            for (int i = 0; i < users.size(); i++) {
                if (username.equals(users.get(i).getLogin()) && password.equals(users.get(i).getPassword())) {
                    b = true;
                    if (users.get(i).getRole().equals("dekan")) {
                        try{
                        while (true) {
                            System.out.println("Dekan sistemine girish edildi\nHansi emeliyyati icra etmek isteyirsiniz?\n1.Telebelerin siyahisi\n2.Laborant yarat\n3.Dekan yarat\n0.Sistemden chix");
                            int index = s.nextInt();
                            s.nextLine();
                            if (index == 1) {
                                List<Telebe> studentList = WriteFile.readStudents();
                                if (studentList.isEmpty()) {
                                    System.out.println("Sistemde telebe yoxdur");
                                } else {
                                    for (int k = 0; k < studentList.size(); k++) {
                                        System.out.println((k + 1) + "-ci " + studentList.get(k));
                                    }
                                }
                            } else if (index == 2) {
                                System.out.println("Nece laborant yaradilacaq?");
                                int countLab = s.nextInt();
                                for (int j = 0; j < countLab; j++) {
                                    WriteFile.writeLaborant();
                                }
                                System.out.println("Emeliyyat ughurla basha chatdi");

                            } else if (index == 3) {
                                System.out.println("Nece dekan yaradilacaq?");
                                int countDek = s.nextInt();
                                for (int j = 0; j < countDek; j++) {
                                    WriteFile.writeDekan();
                                }
                                System.out.println("Emeliyyat ughurla basha chatdi");
                            } else if (index == 0) {
                                
                                break;
                            }
                        }}catch(Exception e){
                            System.out.println("Verilenleri duzgun daxil etdiyinizen emin ");
                    }} else {
                        OUTER:
                        while (true) {
                            System.out.println("Laborant sistemine girish edildi\nHansi emeliyyati icra etmek isteyirsiniz?\n1.Telebe qeydiyyati\n2.Telebe siyahisi\n3.Telebe axtarishi\n4.Telebenin silinmesi\n0.Sistemden chix");
                            int index = s.nextInt();
                            switch (index) {
                                case 1:
                                    System.out.println("Neche telebe qeydiyyatdan kechecek?");
                                    int count = s.nextInt();
                                    for (int j = 0; j < count; j++) {
                                        WriteFile.writeStudent();
                                    }
                                    System.out.println("Emeliyyat ughurla basha chatdi");
                                    break;
                                case 2:
                                    System.out.println("Sistemde qeydiyyatda olan telebelerin siyahisi: ");
                                    WriteFile.readStudents();
                                    break;
                                case 3: {
                                    System.out.println("Axtarmaq istediyiniz telebenin adini ve ya soyadini daxil edin:");
                                    s = new Scanner(System.in);
                                    String search = s.nextLine();
                                    int telebe = 0;
                                    for (int j = 0; j < students.size(); j++) {

                                        if (students.get(j).getName().equalsIgnoreCase(search) || students.get(j).getSurname().equalsIgnoreCase(search)) {
                                            System.out.println("Netice: " + students.get(j));
                                            telebe++;
                                            break;
                                        }
                                    }
                                    if (telebe == 0) {
                                        System.out.println("Melumat sistemde tapilmadi");

                                    }
                                    break;
                                }
                                case 4: {
                                    System.out.println("Telebelerin siyahisi:");
                                    WriteFile.readStudents();
                                    System.out.println("Melumatlarini silmek istediyiniz telebenin indeksini secin:");
                                    int telebe = s.nextInt();
                                    students.remove((telebe - 1));
                                    WriteFile.writeStudentNew(students);
                                    System.out.println("Telebe sistemden silindi");
                                    break;
                                }
                                case 0:
                                    break OUTER;
                                default:
                                    break;
                            }
                        }
                    }
                }
            }
            if (b == false) {
                System.out.println("Daxil etdiyiniz melumatlar dogru deyil");
            }

        }
    }
}
