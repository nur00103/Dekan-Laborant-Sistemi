/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dekanStudent;

/**
 *
 * @author nur13
 */
public class Telebe {
    private String name;
    private String surname;
    private String score;   //Verbal Interpretation

    public Telebe() {
    }

    public Telebe(String name, String surname, String score) {
        this.name = name;
        this.surname = surname;
        this.score = score;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    @Override
    public String toString() {
        return "telebe:" +  name + " " + surname + " " + score +"\n";
    }
    
    
    
}
