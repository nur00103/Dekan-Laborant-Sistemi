
package dekanStudent;
import java.util.Scanner;
public class CheckTrue {

    static Scanner s = new Scanner(System.in);

    public static int num(String message) {
        boolean isTrueNum = false;
        int num = 0;
        while (!isTrueNum) {
            try {
                num = Integer.parseInt(s.nextLine());
                isTrueNum = true;
            } catch (Exception e) {
                System.err.println("Duzgun eded daxil etdiyinizden emin olun!");
                System.out.println(message);
            }
        }
        return num;
    }

    public static String string(String str, String text) {
        boolean isTrueStr = false;
        char letter;
        while (!isTrueStr) {
            if (str.length() == 0) {
                System.err.println("Daxil edilen deyer bosdur");
                System.out.println("Zehmet olmasa " + text + " duzgun daxil edin.");
                str = s.nextLine();
                continue;
            }
            isTrueStr = true;
            for (int i = 0; i < str.length(); i++) {
                letter = str.toLowerCase().charAt(i);
                if (!(letter >= 'a' && letter <= 'z')) {
                    System.out.println("Zehmet olmasa " + text + " duzgun daxil edin.");
                    str = s.nextLine();
                    isTrueStr = false;
                    break;

                }
            }
        }
        return str;
    }

}
