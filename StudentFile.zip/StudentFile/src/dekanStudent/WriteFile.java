/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dekanStudent;

import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import static javafx.scene.input.KeyCode.T;

/**
 *
 * @author nur13
 */
public class WriteFile  {
    Scanner s=new Scanner(System.in);
    public static List<User> readLogin() throws Exception{
        try(FileReader fr=new FileReader("login.txt");
                Scanner s=new Scanner(fr);){
            List<User>  users = new ArrayList<>();
            while(s.hasNext()){ //  Sonraki setir bosh deyilse true
                String[] arr = s.nextLine().split(" ");
                User user = new User(arr[0],arr[1],arr[2]);
                users.add(user);              
            }//System.out.println(users.get(0));  
            return users;
    } 
    }
        public static List<Telebe> readStudents() throws Exception{
        try(FileReader fr=new FileReader("Students.txt");
                Scanner s=new Scanner(fr);){
            List<Telebe>  students = new ArrayList<>();
            while(s.hasNext()){ //  Sonraki setir null deyilse true
                String[] arr = s.nextLine().split(" ");
                Telebe telebe = new Telebe(arr[0],arr[1],arr[2]);
                students.add(telebe);              
            }//System.out.println(users.get(0));
            for (int i = 0; i < students.size(); i++) {
                System.out.println((i+1)+"-ci " +students.get(i));
            }
            return students;
    } 
    }
        public static List<Telebe> readStudents2() throws Exception{
        try(FileReader fr=new FileReader("Students.txt");
                Scanner s=new Scanner(fr);){
            List<Telebe>  students = new ArrayList<>();
            while(s.hasNext()){ //  Sonraki setir null deyilse true
                String[] arr = s.nextLine().split(" ");
                Telebe telebe = new Telebe(arr[0],arr[1],arr[2]);
                students.add(telebe);              
            }
            return students;
    } 
    }
        public static void writeLaborant() throws Exception {
            Scanner s=new Scanner(System.in);
            System.out.println("Istifadeci adini teyin edin");
            String login=s.nextLine();
            System.out.println("Shifre teyin edin");
            String password=s.nextLine();            
        try (FileWriter f = new FileWriter("Login.txt",true);
                BufferedWriter b = new BufferedWriter(f);) {
                System.out.println("");
                b.write(login + " " + password + " laborant");
                b.newLine();
            
        }
    }
        public static void writeDekan() throws Exception {
            Scanner s=new Scanner(System.in);
            System.out.println("Istifadeci adini teyin edin");
            String login=s.nextLine();
            System.out.println("Shifre teyin edin");
            String password=s.nextLine();            
        try (FileWriter f = new FileWriter("Login.txt",true);
                BufferedWriter b = new BufferedWriter(f);) {
                System.out.println("");
                b.write(login + " " + password + " dekan");
                b.newLine();
            
        }
    }
        public static void writeStudent() throws Exception {
            Scanner s=new Scanner(System.in);
            System.out.println("Telebenin adi:");
            String name=s.nextLine();
            System.out.println("Telebenin soyadi");
            String surname=s.nextLine(); 
            System.out.println("Telebenin bali:");
            int score=s.nextInt();
        try (FileWriter f = new FileWriter("Students.txt",true);
                BufferedWriter b = new BufferedWriter(f);) {
                System.out.println("");
                b.write(name + " " + surname + " "+ score);
                b.newLine();
            
        }
    }
        public static void writeStudentNew(List<Telebe>students) throws Exception {
        try (FileWriter f = new FileWriter("Students.txt");
                BufferedWriter b = new BufferedWriter(f);) {
                System.out.println("");
                for (int i = 0; i < students.size(); i++) {
                    b.write(students.get(i).getName() +" "+students.get(i).getSurname()+" "+students.get(i).getScore());
                    b.newLine();
                }
                
            
        }
    }
    
}
